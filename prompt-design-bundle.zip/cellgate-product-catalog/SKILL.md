---
name: cellgate-product-catalog
description: CellGate master product catalog — provides official catalog names, SKUs, pricing (MSRP and dealer), features, connectivity options, service fees, and accessory details for all CellGate products. Use this skill whenever creating any CellGate artifact that references a product by name, SKU, model number, or shorthand. Also trigger when the user asks about CellGate pricing, product specs, hardware options, service fees, MSF rates, SurePath eligibility, readers, credentials, cameras, accessories, or any product comparison. Apply automatically whenever a CellGate product appears in any artifact — dashboards, proposals, quotes, sales materials, presentations, documentation, or internal tools — even if the user doesn't explicitly request catalog compliance. This skill ensures the correct CATALOG NAME is always inserted and provides enrichment data (pricing, features, connectivity) on demand.
---

# CellGate Product Catalog Skill

## Purpose

This skill is the single source of truth for CellGate product naming and pricing. It ensures every artifact uses the **official catalog name** and can enrich any product reference with MSRP, dealer cost, features, connectivity, and service fee data.

## When to Apply

- **Always**: Insert the correct catalog name when any CellGate product appears in an artifact
- **On request**: Provide pricing, features, connectivity, service fees, SurePath eligibility, or accessory details
- **Automatically**: When building quotes, proposals, BOMs, dashboards, or any artifact that references CellGate hardware or services

## Quick Name Resolution

When a user references a product by any identifier (SKU, Dev Portal code, model number, or shorthand), resolve it to the official **CATALOG NAME** from the table below. If the user's context requires a different format (e.g., Dev Portal code for a developer-facing artifact, or SKU for a purchase order), provide that format — but always know and be ready to supply the catalog name.

### Product Family Quick Reference

| User Might Say | Catalog Name | Product Line | Tier |
|----------------|-------------|--------------|------|
| W410, Talkman, T1, S1 | **Watchman 410** | Watchman | S1 |
| W450, EVO, S2 | **Watchman 450** | Watchman | S2 |
| W452, legacy S2 | **Watchman 452** | Watchman | Legacy-S2 |
| W461, slim, surface mount, S3 | **Watchman 461** | Watchman | S3 |
| W461 WP, weatherproof | **Watchman 461 Weatherproof** | Watchman | S3 |
| W462, S3-IP | **Watchman 462** | Watchman | S3-IP |
| W480, touchscreen, S4 | **Watchman 480** | Watchman | S4 |
| W482, S4-IP | **Watchman 482** | Watchman | S4-IP |
| WXL, S5, XL | **Watchman XL** | Watchman | S5 |
| WXL2, S5-IP | **Watchman XL2** | Watchman | S5-IP |
| E1, single door, Entria | **Entría Single Door** | Entría | E1 |
| E1 HID | **Entría Single Door HID** | Entría | E1-HID |
| E4, four door | **Entría Four-Door Controller** | Entría | E4 |
| E32, elevator | **Entría Elevator Controller** | Entría | E32 |
| OP gateway, GW | **OmniPoint Gateway** | OmniPoint | OP-GW |
| EPM, entry point module | **OmniPoint Entry Point Module** | OmniPoint | OP-EPM |
| OP sensor | **OmniPoint Sensor** | OmniPoint | OP-SENSOR |

### Reader Quick Reference

| User Might Say | Catalog Name | Key Feature |
|----------------|-------------|-------------|
| Infinity, CGIMU | **Infinity Reader** | QR + BLE + DESFire + Keypad |
| Halo, CGHSM | **Halo Reader** | BLE + DESFire (slim) |
| Digit, CGDSM | **Digit Reader** | Keypad + DESFire |

---

## Full Product Data

For complete SKU tables, MSRP pricing, dealer costs, features, connectivity options, service fees by market segment, SurePath eligibility, readers/credentials, and accessories, read the appropriate reference file:

- **`references/hardware-catalog.md`** — All hardware SKUs, MSRP, features, connectivity, external camera support
- **`references/service-pricing.md`** — Monthly service fees (MSF) by market segment (Single-Family, Multi-Family, Commercial), activation fees, BLE fees, SurePath
- **`references/readers-credentials.md`** — Readers, key fobs, access cards, pricing
- **`references/accessories.md`** — Mounting kits, cameras, antennas, solar kits, replacement parts, cables

Read the relevant reference file(s) when the user asks for pricing, detailed specs, or when building a quote/proposal/BOM.

---

## Rules

1. **Catalog name first.** Always use the official catalog name in customer-facing artifacts. Internal artifacts may use Dev Portal codes or SKUs when that's the expected format.
2. **Correct the user gently.** If the user says "Talkman," use "Watchman 410" in the artifact but don't lecture — just use the right name.
3. **Connectivity suffix convention.** When specifying a variant, append the carrier: "Watchman 480 (AT&T)" or "Watchman 480 (Verizon)" or "Watchman 482 (VPN/IP)".
4. **Entría accent.** Always use the accent: Entr**í**a, not "Entria".
5. **CONFIDENTIAL.** Dealer cost and internal pricing data should only appear in internal-use artifacts. If the artifact is customer- or investor-facing, use MSRP only.
6. **SurePath eligible models.** Only W482, WXL2, and E4ETH are SurePath eligible. Never claim SurePath for other models.
7. **COMING SOON products.** The E32EC Elevator Controller is marked COMING SOON — flag this in any artifact.
