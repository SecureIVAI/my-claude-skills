---
name: cellgate-terminology
description: Enforces CellGate's mandatory terminology, branding, and language standards across all content. Use this skill whenever creating, editing, or reviewing any CellGate content — marketing copy, sales materials, product documentation, social media posts, internal communications, investor materials, emails, presentations, or any text that references CellGate products, markets, or services. Also trigger when the user mentions CellGate brand guidelines, terminology rules, writing standards, banned words, product naming, or market segment language. Apply even when the user doesn't explicitly request terminology compliance — if the output is CellGate-related content, these rules apply automatically.
---

# CellGate Terminology Standards

This skill defines mandatory terminology rules for all CellGate content. Every substitution, product name, and language choice below reflects a deliberate branding, technical, or strategic decision. Apply all rules automatically when generating or editing CellGate-related content.

---

## 1. Core Terminology Substitutions (11 Rules)

These apply to all content types: marketing collateral, website copy, product documentation, sales materials, social media, and internal communications.

| NEVER Use | ALWAYS Use | Rationale |
|-----------|-----------|-----------|
| "products" or "technologies" | "solutions" | Implies solving problems, not selling hardware |
| "enterprise-grade hosting" | "hosted by Microsoft Azure" | Adds credibility with named provider |
| "mobile app" | "CellGate app" | Brand consistency |
| "internet" (general) | "wired internet" | Differentiates from wifi |
| "portal" | "TrueCloud Connect platform" on first use, then "portal" is acceptable | Stronger branding; reflects system architecture |
| "residential home" or "residences" | "single-family" | Sales channel-specific industry term |
| "tenant" | "resident" | More personal, respectful term |
| "cellular" (alone) | "cellular LTE" | Important network distinction |
| "Bluetooth" (alone) | "Bluetooth contactless entry" | Describes the user experience |
| "Wiegand" (alone) | "26-bit Wiegand" | CellGate only works with 26-bit |
| "CellGate Readers & Credentials" | "CG Readers & Credentials" | Official product abbreviation is CG |

---

## 2. Access Credentials Terminology (3 Rules)

CellGate has moved away from the "Virtual Keys" branding entirely. The new hierarchy is:

- **Access credentials** — Umbrella term covering all credential types (Visitor Passes, Bluetooth contactless entry, etc.)
- **Visitor Passes** — QR or PIN Codes issued to visitors specifically
- **Bluetooth contactless entry** — For residents and authorized users

| NEVER Use | ALWAYS Use | Rationale |
|-----------|-----------|-----------|
| "Virtual keys" (as umbrella term) | "Access credentials" | Umbrella term covering all credential types |
| "Virtual keys" (for visitors) | "Visitor Passes" | Moving away from Virtual Keys branding |
| "QR & PIN Code" | "QR or PIN Code" | QR is more secure; use "or" not "&"; list QR first |

---

## 3. Video Communication Terminology (2 Rules)

CellGate uses both "live video telephone entry" and "video intercom" interchangeably across all content. Target a 50/50 split between the two terms. On first use in a document, introduce both: "live video telephone entry (video intercom)."

"Visitor Management" is the solution category that video intercoms address. Use this framing when describing the problem being solved.

---

## 4. Support Services Terminology (2 Rules)

Support service naming is audience-specific. Never use the generic term "customer support." Always match the service name to the customer segment:

| NEVER Use | ALWAYS Use | Audience |
|-----------|-----------|----------|
| "customer support" (generic) | "Customer Care" | Single-family homeowners only |
| "customer support" (generic) | "Gold Key Service" | Multifamily, HOA, and commercial properties |

---

## 5. Ethernet vs. Wired Internet (Special Case)

The default term for internet connectivity is always "wired internet." The word "ethernet" is reserved for one specific use case only: the **Entria 4-door controller with integrated camera support**, because it connects via ethernet without requiring a separate router.

**Rule of thumb:** When in doubt, use "wired internet."

| Context | Use This Term | Why |
|---------|--------------|-----|
| General marketing use | "wired internet" | Default term for all contexts |
| Entria 4-door with camera integration ONLY | "ethernet" | No separate router needed; technical distinction |

---

## 6. Official Product Names (Always Capitalize Exactly)

Never abbreviate, hyphenate, or modify these names unless specified:

- **Watchman**
- **TrueCloud Connect**
- **Entria**
- **OmniPoint**
- **CG Readers & Credentials**
- **Gold Key Service**
- **Customer Care**

---

## 7. Banned Buzzwords

Never use these terms in any CellGate content — they are overused in the industry and dilute CellGate's authentic voice:

- ~~cutting-edge~~
- ~~revolutionary~~
- ~~game-changing~~
- ~~state-of-the-art~~
- ~~smart~~ (standalone — acceptable when part of a compound like "smart home integration" only if unavoidable)
- ~~users~~ (be specific — say "residents," "property managers," "homeowners," etc.)

---

## 8. Core Messaging (Reference)

Use these exact phrases when applicable:

- **Tagline:** "Wireless where you need it. Wired where you have it."
- **Value Proposition:** "Total Property Security Access"
- **Differentiation:** "We're the only company in the industry with dual-network flexibility"
- **Differentiation Opener:** "Here's what sets CellGate apart:"
- **Platform Statement:** "TrueCloud Connect ties everything together with one simple login…"

---

## 9. Market Structure & Segment Language

### Primary Market Categories

| Market | Definition |
|--------|-----------|
| Multifamily | Rental apartment communities |
| HOA / Condo | Owner-occupied association-governed communities |
| Commercial | Mixed-use, retail, storage, non-residential access control |
| Single-Family | Individual homeowner installations |

### Multifamily Verticals

When discussing multifamily submarkets, use these recognized verticals: Student Housing, Senior Living, Affordable Housing (HUD, Section 8, Tax Credit), Garden-Style Apartments, Mid-Rise / High-Rise, REIT-Owned Communities, Military Housing.

### Revenue & Measurement Language

| Segment | Buyer Perspective | Primary Metric |
|---------|------------------|----------------|
| Multifamily | Cost per Residential Unit | RPU (Per Door) |
| HOA / Condo | Cost per Residential Unit | RPU (Per Door) |
| Commercial | Dollars per Door | Dollars per Door |
| Internal Operations | Deployment Efficiency | Revenue per Device |

**Important:** "Revenue per Device" is an internal operational metric only — never use it in market-facing or customer-facing content.

### Company-Wide Language Standards (Market Structure)

- **Multifamily** — Always one word, no hyphen. Never "Multi-family" or "Multi family."
- **Residential Unit (Door)** — An apartment or home within a property. "Door" is the informal shorthand.
- **Device** — Electronic hardware (Watchman, camera, etc.). Distinct from "Residential Unit."
- **Account = Property** — In CellGate context, an "Account" always refers to a property.
- **RPU** — Total monthly revenue divided by Residential Units (doors). The standard market-facing metric.
- **Revenue per Device** — Operational metric only. Not market-facing.

---

## 10. CellGate Acronyms & Abbreviations

Always expand on first use, then abbreviation is acceptable. Use the dotted form (e.g., "A.C.V.") in formal documents; plain form (e.g., "ACV") in dashboards, code, and internal tools.

### Financial & Revenue

| Acronym | Full Term | Usage Rule |
|---------|-----------|-----------|
| ACV | Annual Contract Value | MRR × 12; use when evaluating dealer portfolios |
| ARPU | Average Revenue Per Unit | Monthly revenue per account/device per segment |
| ARR | Annual Recurring Revenue | Annualized MRR; investor/board reporting only |
| CLV | Customer Lifetime Value | Multi-Res $28,173 vs. Single-Family $9,236 |
| MSF | Monthly Service Fee | Per-device recurring fee; billing-side term for MRR |
| NRR | Net Revenue Retention | CellGate: 95.9% trailing 12-month |
| RMR | Recurring Monthly Revenue | Revenue from MSF; also dealer incentive program |
| RPU | Revenue Per Residential Unit | Market-facing "per door" metric; never "Revenue per Device" externally |

### Device & Pipeline

| Acronym | Full Term | Usage Rule |
|---------|-----------|-----------|
| CGDB | CellGate Database | Transactional DB; mirrored to Fabric as `lh_prod_cgdb_mirrored` |
| DHA | Device Health Alerts | 13+ automated checks on ~28,500 active EXTERNAL devices |
| DHR | Device Health Reports | Scored/ranked pipeline output for support triage |
| FP | Face Plate | Physical front panel — NEVER means "false positive" in CellGate context |
| CJN | Customer Journal Notes | Free-text support notes; origin: "CJ's notes" |
| DoA | Dead on Arrival | RMA: device failed on first install/activation |
| NTF | No Trouble Found | RMA: no defect identified; elevated churn risk |
| RCA | Root Cause Analysis | Structured failure/churn investigation |
| RMA | Return Merchandise Authorization | Device return/replacement process |
| RTF | Return-to-Field | RMA: device cleared, shipped back for redeployment |

### Market & Geography

| Acronym | Full Term | Usage Rule |
|---------|-----------|-----------|
| HHI | Herfindahl-Hirschman Index | Revenue concentration; CellGate 544.7 (healthy, <1,500) |
| MSA | Metropolitan Statistical Area | 112 scored for CellGate market analysis |
| PMC | Property Management Company | 308 PMCs = 20.3% fleet MRR ($270,002/mo) |
| PMS | Property Management System | Yardi, RealPage; CellGate integrates with both |

### Product & Platform

| Acronym | Full Term | Usage Rule |
|---------|-----------|-----------|
| CG R&C | CG Readers & Credentials | Official abbreviation of CellGate Readers & Credentials |
| TCC | TrueCloud Connect | First reference: "TrueCloud Connect"; then "portal" is acceptable |

### Internal Tools & Processes

| Acronym | Full Term | Usage Rule |
|---------|-----------|-----------|
| PPAM | Priority Project Account Management | MyCSHelp case type from Sales to Client Success |
| PPIP | Priority Project Implementation Process | Installation streamlining process |
| SERF | Sales Engineer Request Form | Engineering time request/scheduling |
| SIEH | Sales Issue Escalation Help | MyCSHelp case type for sales issues |
| PICC Line | Priority Incident Customer Care | Teams channel for Sales → Support real-time escalation |

---

## 11. Dealer Hierarchy & Engagement Tiers

### Dealer Types (Ascending Responsibility)

| Type | Capabilities | RMR Eligible? |
|------|-------------|---------------|
| **Installing Dealer** | Physical installation; Dealer Installer App | Yes |
| **Admin Dealer** | System admin + multi-login portal; no billing | Yes |
| **Billing Dealer** | Billed for end-user MSFs + admin + account mgmt | Yes |
| **Wholesale Dealer** | Billing + Tier 1 support + MSF discounts; special contract | No (Wholesaler discount instead) |

### Engagement Tiers

| Tier | Criteria | Key Metric |
|------|----------|-----------|
| **Champion** | High volume, consistent activity | 22 dealers, avg 1,778 devices each |
| **At-Risk** | Declining engagement/activity | Top 20 = $89,820/month exposure |
| **Dormant** | No activation in 180+ days | 2,715 dealers; reactivation opportunity |

---

## 12. Device States & Pipeline Terms

| Term | Definition | Key Distinction |
|------|-----------|----------------|
| **Ghost Device** | Intermittent/unstable connectivity; 300-second timeout | Not simply "offline" — appears active briefly, then drops |
| **Unresponsive Device** | No heartbeat + no command response | Requires physical field visit |
| **P1-PERSISTENT** | Critical across multiple consecutive runs | Chronic, unresolved; escalate first |
| **Inventory Sitter** | Dealer holds unactivated device 30+ days | Not generating MSF; 118 dealers affected |
| **Squirrel (SQUIRREL-001)** | Permanent blacklist for wildlife damage | Rule 0, confidence 1.0; removed from all monitoring |
| **Product Wave** | Multiple RMAs share same model + root cause in a month | Suggests manufacturing defect; needs engineering review |
| **Repeat RMA** | 2+ returns within 12-month lookback | Automatic churn risk flag |
| **Orphan Account** | Active account with no dealer in Salesforce | 7,029 accounts = $305,520/mo unattributed MRR |
| **Kaizen Engine** | Automatic model calibration in Sentinel Pipeline | Auto-tunes thresholds; no manual recalibration needed |
| **Sentinel Pipeline** | Next-gen predictive churn detection (v3) | Fuses device health + billing + support + Salesforce data |

---

## 13. Churn & Revenue Terms

| Term | Definition |
|------|-----------|
| **Preventable Churn** | 42.3% of total — billing failures, product expectations, pricing, customer service (2.7% annualized) |
| **Non-Preventable Churn** | 57.7% of total — property sold, business closure, competitive loss (3.6% annualized) |
| **Organic Churn** | ~0.53%/month excluding January Batch Cleanup |
| **January Batch Cleanup** | Annual mass deactivation of long-delinquent accounts each January; inflates that month's churn 3–6× above normal |
| **Churn Floor** | ~3.6% annual structural minimum; theoretical max NRR improvement caps at ~96% |
| **Revenue at Risk** | Total MRR associated with devices flagged by health alerts |
| **White Space** | ZIP codes adjacent to existing installs with no device presence; 7,189 identified |
| **Time-to-First-Activation** | Days from dealer onboarding to first device activation; median 366 days |

---

## 14. Support Channels & Internal Tools

| Tool/Channel | Purpose | Audience |
|-------------|---------|----------|
| **Customer Care** | Support tier for single-family homeowners | Single-family only |
| **Gold Key Service** | Premium support for multifamily, HOA, commercial | Multifamily/HOA/Commercial |
| **Hotline** | Priority technical support for top-tier dealer partners | At-Risk, High ACV, Strategic, Gold/Platinum Certified dealers |
| **PICC Line** | Real-time Teams channel: Sales → Technical Support | Sales team (during active customer/dealer engagement) |
| **MyCSHelp** | Salesforce-based priority request submission | Sales team (PPAM and SIEH case types) |

---

## 15. Salesforce Field Notes

| Field | Usage Rule |
|-------|-----------|
| `Account_Type__c` | 41% null (legacy pre-2021); use `Industry` as fallback |
| `Kit_Model_2__c` | Always use for GROUP BY; `Kit_Model_Formula__c` is NOT groupable |
| `Dealer__c` | NOT groupable; use `DealerId__r.Name` instead |
| `Deactivation_Outcome__c` | Validated root cause for churn; audited against preventable/non-preventable taxonomy |

---

## Conflict Check Summary

All rules have been validated for internal consistency. Key clarifications on terms that appear in multiple sections:

1. **"single-family"** appears in both Section 1 (as a substitution for "residential home/residences") and Section 9 (as a market category). These are aligned — "Single-Family" is the correct market segment term and replaces informal alternatives.
2. **"Residential Unit"** (Section 9) is a measurement unit (a "door"), not a market segment. It does not conflict with the Section 1 rule banning "residential home/residences" — those are segment-level terms that should be replaced with "single-family."
3. **"Account"** equals "Property" (Section 9). This is an internal mapping convention and does not conflict with any terminology substitution rules.
4. **Support service naming** (Section 4) aligns with market categories (Section 9): "Customer Care" maps to Single-Family; "Gold Key Service" maps to Multifamily, HOA/Condo, and Commercial.
5. **"Multifamily"** spelling (Section 9: one word, no hyphen) is consistent across all sections. No section uses "multi-family."
6. **"FP"** always means "Face Plate" in CellGate context (Section 10/12), never "false positive."
7. **"RPU"** is market-facing (Sections 9/10); "Revenue per Device" is internal-only.
8. **Dealer types** (Section 11) and engagement tiers are distinct classifications — a Billing Dealer can be a Champion or Dormant.

---

## Quick-Reference Checklist

When reviewing CellGate content, verify:

1. No banned buzzwords (Section 7)
2. All product names capitalized exactly (Section 6)
3. "Virtual keys" replaced with "access credentials" or "Visitor Passes" (Section 2)
4. "Wired internet" used by default; "ethernet" only for Entria 4-door (Section 5)
5. Support services match audience: Customer Care (single-family) vs. Gold Key Service (multifamily/HOA/commercial) (Section 4)
6. "TrueCloud Connect platform" on first reference, "portal" acceptable thereafter (Section 1)
7. "Multifamily" is one word, no hyphen (Section 9)
8. Market-facing content uses RPU, not Revenue per Device (Section 9)
9. "Resident" not "tenant"; "solutions" not "products" (Section 1)
10. Video terms split 50/50 between "live video telephone entry" and "video intercom" (Section 3)
11. All acronyms expanded on first use (Section 10)
12. "FP" = Face Plate, never false positive (Section 10)
13. Dealer types use correct hierarchy names (Section 11)
14. Device states use exact terms: Ghost Device, Unresponsive, P1-PERSISTENT (Section 12)
