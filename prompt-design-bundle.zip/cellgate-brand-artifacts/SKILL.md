---
name: cellgate-brand-artifacts
description: Applies CellGate's official brand guidelines — colors, typography, logo rules, voice, and visual identity — to all artifacts (React, HTML, SVG, dashboards, landing pages, presentations, and UI components). Use this skill whenever creating any visual artifact for CellGate, including dashboards, web pages, marketing materials, data visualizations, internal tools, reports, or any UI that should carry CellGate branding. Also trigger when the user mentions CellGate brand colors, CellGate styling, CellGate-themed, or asks for anything "on brand" for CellGate. Apply automatically whenever an artifact is being created in a CellGate context — even if the user doesn't explicitly request brand compliance. This skill complements the cellgate-terminology skill (which handles language rules) by handling visual design rules.
---

# CellGate Brand Guidelines for Artifacts

Apply these rules to every visual artifact (React, HTML, SVG, dashboard, chart, landing page, email template, etc.) created for CellGate. These specifications derive from the official CellGate Brand Guidelines v02/26 (2026).

---

## 1. Color System

### Primary Palette

Use CSS variables for consistency. Define these at the `:root` or top of every artifact:

```css
:root {
  /* PRIMARY COLORS */
  --cg-teal: #02a8a5;        /* PMS 2399 C — icons, buttons, bullet points, section backgrounds */
  --cg-blue: #007dba;        /* PMS 7461 — logo accent, CTAs, decorative elements, frames */
  --cg-navy: #064481;        /* PMS 654 C — titles, headings, bold/prominent text */
  --cg-red: #da291c;         /* PMS 485 C — logo accent, CTAs, decorative elements, alerts */

  /* SECONDARY COLORS */
  --cg-light-blue: #0e94ca;  /* PMS 801 C — Watchman accent, decorative */
  --cg-lighter-blue: #95d3e9;/* PMS 2975 — Watchman accent, light backgrounds */
  --cg-dark-gray: #333333;   /* PMS Black C — primary body text, logo text */
  --cg-gold: #eaba09;        /* PMS 10-15 C — Gold Key, camera integration emphasis */

  /* LOGO-SPECIFIC (bright background variant) */
  --cg-logo-green: #572930;  /* PMS 504 C — logomark element */

  /* SUPPLEMENTAL (derived for UI use) */
  --cg-white: #ffffff;
  --cg-light-gray: #f5f6f8;  /* backgrounds, cards */
  --cg-border: #e0e4e8;      /* subtle borders */
}
```

### Color Application Rules

| Element | Color | Variable |
|---------|-------|----------|
| Page/section headings, titles | Dark Blue Navy | `--cg-navy` |
| Body text | Dark Gray | `--cg-dark-gray` |
| Primary buttons, CTAs | Teal OR Blue | `--cg-teal` or `--cg-blue` |
| Secondary buttons | Blue outline on white | `--cg-blue` border |
| Links | Blue | `--cg-blue` |
| Hover states | Darken by 10% or use Navy | `--cg-navy` |
| Icons, bullet points | Teal | `--cg-teal` |
| Alert/error states | Red | `--cg-red` |
| Success states | Teal | `--cg-teal` |
| Warning states | Gold | `--cg-gold` |
| Section backgrounds (alternating) | White / Light Gray | `--cg-white` / `--cg-light-gray` |
| Hero/banner backgrounds | Navy, Blue, or Teal | any primary dark |
| Decorative accents, dividers | Blue-to-Red gradient | `linear-gradient(to right, --cg-blue, --cg-red)` |
| Chart primary series | Teal → Blue → Navy → Red → Gold | in order of data series |

### Gradient Usage

The official CellGate gradient is **blue to red** (`--cg-blue` → `--cg-red`). Use for:
- Divider lines (e.g., below headers, above footers)
- Hero section accent bars
- Progress indicators

```css
.cg-gradient-bar {
  height: 4px;
  background: linear-gradient(to right, #007dba, #da291c);
}
```

---

## 2. Typography

### Font Stack

| Context | Font | Fallback |
|---------|------|----------|
| CellGate logo | Maven Pro | sans-serif |
| Product brand names (Watchman, OmniPoint, Entría, Readers, SurePath) | DIN 2014 Narrow | sans-serif |
| TrueCloud Connect brand name | DIN 2014 Narrow Regular | sans-serif |
| Gold Key brand name | Dunbar Text Bold + Globe Grotesk Display | sans-serif |
| Website / artifacts | Open Sans | -apple-system, system-ui, sans-serif |

### Artifact Font Rules

For web artifacts, always use **Open Sans** as the base font. Import from Google Fonts:

```html
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">
```

For React artifacts using Tailwind, apply via the `font-family` style or use:
```css
font-family: 'Open Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
```

### Type Scale

| Element | Size | Weight | Color |
|---------|------|--------|-------|
| H1 (page title) | 28–32px | 700 | `--cg-navy` |
| H2 (section heading) | 22–24px | 700 | `--cg-navy` |
| H3 (subsection) | 18–20px | 600 | `--cg-navy` or `--cg-dark-gray` |
| Body text | 14–16px | 400 | `--cg-dark-gray` |
| Small/caption | 12–13px | 400 | `#666666` |
| Button text | 14px | 600 | White (on filled) or `--cg-blue` (outline) |

---

## 3. Logo Usage in Artifacts

### When to Include the Logo

Include the CellGate logo in artifacts that are **external-facing** or **standalone** (dashboards, reports, landing pages, email templates, exported documents). Omit it from **internal tooling fragments** or **embedded components**.

### Logo Rendering Rules

Since actual logo image files may not be available in the artifact environment, render the CellGate logomark as an **SVG approximation** or use the text-based representation:

**Text-based logo (acceptable for artifacts):**
```html
<span style="font-family: 'Maven Pro', sans-serif; font-size: 24px; color: #333333; font-weight: 400;">
  <span style="color: #007dba;">)))((</span> cellgate<sup style="font-size: 10px;">®</sup>
</span>
```

### Logo Rules (Do NOT Violate)

- **Never** change the casing: it is always lowercase `cellgate` in the logo (but `CellGate` when typed in text)
- **Never** crop, stretch, distort, rotate, flip, or tilt the logo
- **Never** add drop shadows or effects to the logo
- **Never** use non-corporate colors on the logo
- **Never** overlap the logomark with the text
- **Never** use the text without the logomark
- **Never** use non-corporate fonts for the logo
- **Bright backgrounds**: logo uses blue + red mark, dark gray text
- **Dark backgrounds**: logo uses blue + red mark, white text

---

## 4. Product Brand Colors (Per-Product Theming)

When building artifacts specific to a CellGate product line, apply the product's accent color:

| Product | Primary Color | Secondary Color | Hex Values |
|---------|--------------|----------------|------------|
| Watchman® | Light Blue | Lighter Blue | `#0e94ca`, `#95d3e9` |
| OmniPoint® | Red | White | `#e32a29`, `#ffffff` |
| Entría™ | Green (primary) | Green (secondary) | `#25937e`, `#39b6a2` |
| CG Readers & Credentials | Coral/Salmon | Periwinkle Blue | `#ec7f66`, `#7ba5d1` |
| SurePath™ | Blue | White | `#007DBA`, `#ffffff` |
| TrueCloud Connect™ | Blue | Gray | `#047dba`, `#888787` |
| Gold Key Service | Gold | Dark Gray | `#eaba09`, `#333333` |

Always pair product colors with the CellGate corporate palette — product colors accent, they don't replace the brand.

---

## 5. Component Patterns

### Buttons

```css
/* Primary button */
.cg-btn-primary {
  background-color: #02a8a5;
  color: #ffffff;
  border: none;
  border-radius: 6px;
  padding: 10px 24px;
  font-family: 'Open Sans', sans-serif;
  font-weight: 600;
  font-size: 14px;
  cursor: pointer;
  transition: background-color 0.2s;
}
.cg-btn-primary:hover {
  background-color: #028a87;
}

/* Secondary button */
.cg-btn-secondary {
  background-color: transparent;
  color: #007dba;
  border: 2px solid #007dba;
  border-radius: 6px;
  padding: 8px 22px;
  font-family: 'Open Sans', sans-serif;
  font-weight: 600;
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s;
}
.cg-btn-secondary:hover {
  background-color: #007dba;
  color: #ffffff;
}
```

### Cards

```css
.cg-card {
  background: #ffffff;
  border: 1px solid #e0e4e8;
  border-radius: 8px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
}
```

### Data Visualization (Charts)

When using Recharts, Chart.js, D3, or Plotly, apply CellGate colors in this order for data series:

```javascript
const CG_CHART_COLORS = [
  '#02a8a5', // Teal (primary series)
  '#007dba', // Blue
  '#064481', // Navy
  '#da291c', // Red
  '#eaba09', // Gold
  '#0e94ca', // Light Blue
  '#95d3e9', // Lighter Blue
  '#333333', // Dark Gray
];
```

### Tables

- Header row: `--cg-navy` background, white text
- Alternating rows: white / `--cg-light-gray`
- Border: `--cg-border`

### Navigation / Headers

- Background: white or `--cg-navy`
- Active/selected indicator: `--cg-teal` underline or left border
- Text: `--cg-dark-gray` (light bg) or white (dark bg)

---

## 6. Layout & Spacing

- Use **8px grid** for spacing (8, 16, 24, 32, 48, 64px)
- Max content width: **1200px** centered
- Card padding: **24px**
- Section padding: **48px** vertical, **24px** horizontal
- Border radius: **6–8px** for cards/buttons, **4px** for inputs

---

## 7. Dark Mode / Dark Backgrounds

When building on dark backgrounds:
- Text: white (`#ffffff`)
- Secondary text: `#b0b8c4`
- Background: `--cg-navy` (`#064481`) or `#1a2332`
- Cards on dark: `rgba(255,255,255,0.08)` with white text
- Logo: white text variant (logomark retains full color)
- Buttons: use lighter teal/blue; ensure WCAG AA contrast

---

## 8. Brand Voice in UI Copy

When writing microcopy, labels, or descriptions in artifacts:
- **Professional & Personable** — not stiff, not casual
- **Approachable & Friendly** — no condescension
- **Technical, Yet Simple** — plain language; avoid jargon unless audience is technical
- **Optimistic & Communicative** — positive framing

Refer to the **cellgate-terminology** skill for all language/naming rules.

---

## 9. Brand Name Text Rules (Quick Reference)

Always spell these exactly when they appear in artifact text:

| Correct | Incorrect |
|---------|-----------|
| CellGate | Cell-gate, Cell Gate, Cellgate |
| cell-gate.com | cellgate.com |
| Watchman | WATCHMAN, Watch Man, WatchMan |
| OmniPoint | OMNIPOINT, Omni Point, Omnipoint |
| Entría | ENTRÍA, Entria (no accent) |
| SurePath | Surepath |
| TrueCloud Connect | Truecloud Connect, True Cloud Connect |
| CellGate Readers & Credentials (or Readers & Credentials) | CellGate Readers & Credentials with "CellGate" prefix is acceptable |

**Tagline (2025+):** "TOTAL PROPERTY SECURITY ACCESS" — replaces the old "Total Property Wireless Access." Remove all references to the old tagline.

**Sub-tagline:** "Wireless where you need it. Wired where you have it."

---

## 10. Checklist Before Presenting an Artifact

Before finalizing any CellGate-branded artifact, verify:

1. CSS variables defined for all CellGate colors
2. Open Sans loaded as the base font
3. Headings use `--cg-navy`; body uses `--cg-dark-gray`
4. Buttons use teal (primary) or blue (secondary)
5. Charts use `CG_CHART_COLORS` array in order
6. Gradient bar uses blue → red where decorative dividers appear
7. No banned buzzwords in UI text (see cellgate-terminology)
8. All product names spelled correctly per Section 9
9. Logo (if present) follows bright/dark background rules
10. 8px spacing grid maintained
11. Sufficient contrast (WCAG AA minimum)
12. "Total Property Security Access" tagline (not the old wireless version)
