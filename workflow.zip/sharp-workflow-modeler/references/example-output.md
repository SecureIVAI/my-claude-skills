# Example output pattern

Use this response pattern when the user gives you raw notes and asks for a modeled process.

## BPMN-ready structure
**Process name:** Cancellation retention flow  
**Model type:** as-is draft  
**Trigger:** Customer communicates intent to cancel  
**End result:** Customer either retained on revised terms or cancellation completed correctly  
**Primary customer/recipient:** Customer, revenue operations, and service teams

**Pools / lanes:**
- Customer
- Frontline support
- Retention specialist
- Billing / provisioning

**Main flow:**
1. [Customer] Start event: Express intent to cancel.
2. [Frontline support] Task: Validate account and contract status.
3. [Frontline support] Gateway: Does request qualify for retention handling?
   - Yes -> route to Retention specialist.
   - No -> proceed with cancellation handling.
4. [Retention specialist] Task: Review customer context and churn reason.
5. [Retention specialist] Task: Present retention option.
6. [Customer] Gateway: Accept offer?
   - Yes -> apply revised terms and confirm retention outcome.
   - No -> continue cancellation.
7. [Billing / provisioning] Task: Stop billing and schedule service termination if needed.
8. [Frontline support] End event: Confirm final outcome to customer.

**Key exceptions / alternate paths:**
- Contract already expired
- System cannot apply offer automatically
- Customer withdraws cancellation after escalation

**Notes for BPMN conversion:**
- Human tasks: validate account, review churn reason, present offer, confirm outcome
- Candidate system tasks: update billing, send confirmation, schedule termination
- Candidate gateways: qualifies for retention, accepts offer, service already terminated

## Rewritten process narrative
The process starts when a customer indicates they want to cancel. Support first verifies the account, current contract state, and whether the request should be routed into the retention path. If it qualifies, a retention specialist reviews the account context and the reason for churn, then presents an offer or alternative. If the customer accepts, the revised arrangement is applied and confirmed. If the customer declines, the cancellation path continues through billing and service changes, and the customer receives final confirmation.

## Corrected workflow model
### Lane: Customer
1. Express intent to cancel
2. Decide whether to accept retention offer

### Lane: Frontline support
3. Validate account and contract status
4. Determine whether request qualifies for retention handling
5. Confirm final outcome to customer

### Lane: Retention specialist
6. Review customer context and churn reason
7. Present retention option
8. Record customer decision

### Lane: Billing / provisioning
9. Stop future billing
10. Schedule service termination if required

## Critique against sharp principles
### What works
- Clear commercial outcome
- Distinct customer decision point
- Meaningful handoff between support and retention

### Modeling defects
- Trigger may be hidden in notes rather than stated explicitly
- Billing and provisioning are often collapsed into one vague back-office step
- Qualification criteria for retention are frequently treated as informal judgment instead of explicit decision logic

### Why the defects matter
These defects make the flow hard to validate, create inconsistent handling, and obscure where delay or leakage occurs.

### Pragmatic options
- **Strict modeling option:** separate retention qualification, offer presentation, customer decision, and cancellation completion into explicit gateways and tasks.
- **Workshop-friendly option:** keep one decision for qualification and one for offer acceptance, with policy notes outside the flow.
- **Operational option:** combine support and retention into one lane if the same team does both in practice.

### Open questions / assumptions
- Is retention eligibility rule-based or agent discretion?
- Does billing stop immediately or after a scheduled date?
- Which team owns final confirmation?
