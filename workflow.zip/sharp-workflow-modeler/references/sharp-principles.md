# Sharp-style workflow modeling principles

This reference captures a compact working set of principles commonly associated with Alec Sharp's workflow modeling approach in public descriptions, talks, and summaries. Use it as disciplined guidance. Do not claim to quote the book unless the user provides text from it.

## Core principles

1. **Show the flow of work**
   The central purpose of a workflow model is to show how work moves.

2. **Flow first, detail later**
   Establish sequence and responsibility before expanding rules, fields, policies, and edge detail.

3. **Show every actor that holds the work**
   Actors matter because work changes hands. Lanes exist to make ownership and handoffs visible.

4. **Use simple left-to-right flow where possible**
   Favor readability and natural sequence.

5. **Use the simplest symbol set that preserves meaning**
   Avoid clutter and pseudo-precision.

6. **Name activities with action language**
   Prefer verb-noun labels because they express work performed, not departments, artifacts, or states.

7. **Model from trigger to result**
   A process should produce a definable result for someone.

8. **Separate levels of abstraction**
   Keep process, subprocess, and procedure detail distinct.

9. **Model only useful exceptions**
   Include alternate paths that matter to performance, risk, quality, or experience.

10. **Use the model to improve the process, not just document it**
    Good modeling surfaces pain points, unnecessary handoffs, avoidable approvals, weak decisions, and redesign opportunities.

## Interpretation notes

### What to include as an actor
Include an actor when that role or system genuinely receives or owns the work. Do not create a lane just because a department is mentioned in passing.

### What counts as an activity
An activity changes, decides, validates, communicates, or completes work. A dashboard, report, field, queue, rule, or status is not automatically an activity.

### When to show a system
Show a system as a lane only if the automation materially performs work or the handoff to or from that automation matters to the process. Otherwise mention the system in notes.

### When to split into subprocesses
Split when the parent model becomes unreadable or when a recurring cluster of steps has its own trigger, logic, or reuse value.

### When to challenge a step
Challenge steps that look like:
- pure routing
- duplicate approvals
- status updates with no decision value
- checks that repeat upstream work
- tasks named after departments or outputs rather than actions

## Language discipline

### Preferred activity names
- Receive request
- Validate eligibility
- Review reason for cancellation
- Prepare retention offer
- Record outcome
- Confirm cancellation

### Weak activity names
- Request validation
- Eligible customer
- Retention team
- Cancellation completed
- Send to finance

## Recommended critique lens

When reviewing a model, ask:
- What triggers this process?
- What result does it deliver?
- Who holds the work at each point?
- Where does work wait, loop, or get handed off?
- Which decisions truly change the path?
- Which activities are mislabeled, redundant, or over-detailed?
- Which parts belong in notes, rules, or subprocesses instead?
- What change would reduce friction without losing control?
