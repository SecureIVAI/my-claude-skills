---
name: sharp-workflow-modeler
description: apply alec sharp-style workflow modeling discipline to informal process notes, requirements documents, and plain-english process descriptions. use when chatgpt needs to turn messy process inputs into a documented as-is or to-be workflow, bpm-ready structure, rewritten process narrative, corrected cross-functional flow, or critique grounded in sharp-style workflow modeling best practices, especially for handoffs, actors, scope, naming, exceptions, and pragmatic redesign options.
---

# Sharp Workflow Modeler

Use this skill to transform incomplete process material into a clear, reviewable workflow model that is ready to become BPMN or another cross-functional process map.

The goal is not just to document steps. The goal is to show the flow of work clearly enough that stakeholders can validate it, challenge it, and improve it.

## Default workflow

Follow this sequence unless the user explicitly asks for only one output.

1. **Establish the process frame**
   - Identify the process name, trigger, end result, scope, customer or recipient of the result, and whether the request is asking for **as-is**, **to-be**, or both.
   - If the source is ambiguous, resolve ambiguity with grounded assumptions from the material and label them clearly as assumptions.

2. **Extract the flow of work**
   - Identify each actor or role that holds, moves, decides on, or completes work.
   - Reconstruct the end-to-end sequence, including major decisions, handoffs, waits, rework, exceptions, and system steps only when they materially affect flow.

3. **Normalize the model**
   - Rewrite activities in **verb-noun** form.
   - Remove labels that are really departments, states, screens, reports, or vague phrases.
   - Separate activities from routing, business rules, data, and commentary.
   - Keep the model simple enough to read while preserving essential handoffs and decisions.

4. **Assess the model against sharp-style principles**
   - Check scope, actor visibility, sequence clarity, handoff quality, decision logic, exception coverage, naming quality, and outcome orientation.
   - Call out what is missing, overloaded, duplicated, or positioned at the wrong level of detail.

5. **Produce the deliverable set**
   Unless the user asks otherwise, provide these four sections in this order:
   - **BPMN-ready structure**
   - **Rewritten process narrative**
   - **Corrected workflow model**
   - **Critique against sharp principles**

6. **Add pragmatic redesign options**
   - Explain the "why" behind each major correction.
   - Offer pragmatic alternatives when strict modeling discipline may be too heavy for the audience, tooling, or workshop maturity.

## Modeling rules

Apply these rules consistently.

### 1. Model the flow of work first
A workflow model exists to show how work moves from trigger to result. Favor sequence, dependency, and responsibility over decorative detail.

### 2. Show every actor that actually holds the work
Include people, teams, roles, and systems only when they truly receive, own, transform, decide on, or pass along work.

### 3. Define a clean trigger and result
Every model should answer:
- What starts the process?
- What result does the process deliver?
- For whom?

If trigger or result is missing from the source, infer cautiously and mark the inference.

### 4. Keep scope end-to-end
Prefer business-process scope over tiny procedure fragments or giant value-chain abstractions. If the source blends levels, split them explicitly into:
- process
- subprocess
- procedure or task detail

### 5. Use verb-noun names for activities
Good examples:
- Review cancellation request
- Verify contract status
- Offer retention incentive
- Confirm cancellation

Avoid:
- Cancellation review
- Customer unhappy
- Retention team
- Sent to manager
- Approved request

### 6. Do not use tasks to express routing when a handoff or gateway is the real meaning
If a step only says "send to X," determine whether the model should instead show:
- a handoff to another actor, or
- a decision that directs work to one path or another

### 7. Separate work from rules and data
Business rules, policies, required data, SLAs, and notes are important, but they are not all activities. Represent them as annotations in prose or supporting notes unless they materially change the path.

### 8. Show exceptions and rework when they matter
Do not over-model edge cases, but do include exceptions that materially affect cycle time, quality, customer experience, cost, or escalation.

### 9. Preserve one readable level of detail per model
If the material mixes strategic outcomes, individual clicks, and policy notes, create a primary model at one level and list lower-level detail separately.

### 10. Prefer simple structure over notation theater
A simpler, accurate, reviewable model is better than a bloated pseudo-BPMN diagram. Keep it ready for BPMN without forcing every BPMN construct into the explanation.

## Output contract

When the user asks to build or reconstruct a process, default to this structure.

### BPMN-ready structure
Use this template:

```markdown
## BPMN-ready structure
**Process name:**
**Model type:** as-is | to-be | hybrid draft
**Trigger:**
**End result:**
**Primary customer/recipient:**

**Pools / lanes:**
- Lane 1:
- Lane 2:
- Lane 3:

**Main flow:**
1. [Lane] Start event: ...
2. [Lane] Task: Verb noun
3. [Lane] Gateway: Question?
   - Yes -> ...
   - No -> ...
4. [Lane] Task: ...
5. [Lane] End event: ...

**Key exceptions / alternate paths:**
- Exception 1:
- Exception 2:

**Notes for BPMN conversion:**
- Mark which steps are human tasks vs system tasks.
- Identify candidate message flows, timers, data objects, and subprocesses only when clearly supported.
```

### Rewritten process narrative
Write a concise narrative from trigger to result in plain business language. Make the flow understandable to stakeholders who will never read BPMN.

### Corrected workflow model
Provide a text-first cross-functional model using lanes and numbered steps. This should read like a clean swimlane draft.

Use this style:

```markdown
## Corrected workflow model
### Lane: Customer
1. Submit cancellation request

### Lane: Support
2. Validate account and contract status
3. Determine whether request qualifies for retention handling

### Lane: Retention
4. Review customer context and churn reason
5. Present retention offer
6. Record customer decision

### Lane: Billing
7. Stop future billing

### Lane: Support
8. Confirm final outcome to customer
```

### Critique against sharp principles
Use these subsections:
- **What works**
- **Modeling defects**
- **Why the defects matter**
- **Pragmatic options**
- **Open questions / assumptions**

## How to critique

When critiquing a draft model or reconstructing one from notes, check for these failure modes:

- Missing or fuzzy trigger
- Missing end result
- Unclear customer or recipient of the result
- Actors hidden inside steps instead of shown as lanes
- Activities named as nouns, systems, states, or department labels
- Routing disguised as work
- Handoffs missing or implied but not modeled
- Decisions without clear questions or branch criteria
- Exceptions and rework omitted even though the notes mention them
- Mixed levels of detail in the same model
- Control steps, approvals, or reports included without explaining their value
- System behavior shown as if a human performs it, or vice versa
- Local optimization that harms end-to-end flow

## Pragmatic options

Be strict in diagnosis, but practical in recommendations.

Whenever you propose a correction, provide one of these options if useful:

- **Strict modeling option:** best for a canonical process model or BPMN conversion
- **Workshop-friendly option:** lighter version for stakeholder review sessions
- **Operational option:** simpler version for SOP drafting or implementation planning

Explain the tradeoff in one sentence each.

## Special handling by input type

### Meeting notes from a working session
- Expect ambiguity, contradictions, and skipped steps.
- Reconstruct the likely real flow.
- Separate what participants said from what the process logically requires.
- Flag unresolved disputes as open questions, not facts.

### Requirements document
- Distinguish stated requirements from inferred current-state behavior.
- Separate business requirements, system requirements, and workflow steps.
- Do not mistake validations, fields, or rules for standalone activities unless they drive work.

### Plain-English process description
- Infer candidate actors, events, and decisions.
- Convert narrative phrasing into a disciplined process structure.
- Surface missing scope, exceptions, and outcomes.

## Quality bar before finalizing

Before answering, verify that the output:

- has a named process
- has a clear trigger and end result
- shows actors explicitly
- uses verb-noun activity names
- distinguishes flow, decisions, and notes
- keeps a consistent level of detail
- includes important exceptions if the source supports them
- explains why major corrections were made
- offers pragmatic options where the strict model may feel heavy

## Reference files

Use these bundled references when needed:
- See `references/sharp-principles.md` for a concise principle set and interpretation notes.
- See `references/example-output.md` for a sample response pattern.
- See `references/claude-system-prompt.md` when the user wants to adapt this skill into Claude project instructions or a system prompt.
