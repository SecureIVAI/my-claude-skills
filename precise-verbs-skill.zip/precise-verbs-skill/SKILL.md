---
name: precise-verbs-skill
description: Apply this skill whenever writing or editing business communications, executive summaries, emails, reports, or any professional content. Enforces use of descriptive, precise, and strong verbs to produce clear, compelling prose consistent with McKinsey/BCG consulting standards.
---

## Core Principle

Strong verb choice is the single highest-leverage editing action. Every weak or imprecise verb is an opportunity to sharpen meaning, accelerate reading, and project competence. Apply these rules in every draft and revision.

---

## Rule 1 — Replace Imprecise Verb Phrases with Single Precise Verbs

Never use a multi-word phrase when a single verb exists. Scan every sentence for these patterns and replace immediately.

| Imprecise | Precise |
|---|---|
| be in agreement | agree |
| be capable of / have the capability to | can, are able |
| carry out an inspection of | inspect |
| do a verification of | verify |
| draw a conclusion | infer, conclude |
| give an answer | answer |
| give rise to | cause |
| have a requirement | require |
| have knowledge of | know |
| have plans | plan |
| hold a meeting | meet |
| keep track of | track |
| make a distinction | distinguish |
| make a proposal | propose |
| make a suggestion | suggest |
| make changes to | change |
| make contact with | meet, contact |
| perform the printing | print |
| provide assistance | help |
| reach a decision | decide |
| render inoperative | break |
| serve to define | define |
| show improvement | improve |

---

## Rule 2 — Replace Weak Verbs with Strong, Specific Alternatives

Weak verbs obscure meaning. When you encounter the words below, always substitute a more precise alternative that reflects the actual action taken.

| Weak Verb | Strong Alternatives |
|---|---|
| **help** | collaborate, encourage, facilitate, restore, revive, stimulate |
| **make** | compose, construct, formulate, generate, prepare, produce |
| **say** | articulate, convey, communicate, declare, express, reveal |
| **show** | demonstrate, disclose, display, explain, present, reveal |
| **support** | brace, bolster, assist, reinforce, strengthen, undergird, uphold |

Choose the alternative that most precisely describes what is actually happening — do not substitute randomly.

---

## Rule 3 — Use the Descriptive Verb Library

When drafting, prefer verbs from the following curated list over generic alternatives. Use the appropriate form: plural, gerund (-ing), or past tense as grammar requires.

**A–C:** accelerate, achieve, activate, align, alleviate, amplify, analyze, authenticate, automate, bolster, boost, build, capture, centralize, clarify, collaborate, consolidate, construct, coordinate, create, cultivate, customize

**D–F:** define, deploy, design, detect, determine, develop, differentiate, digitize, distribute, document, drive, elevate, enable, enhance, ensure, establish, evaluate, execute, expand, expedite, extract, facilitate, filter, forecast, fortify, fulfill

**G–M:** generate, govern, identify, improve, integrate, investigate, launch, leverage, maximize, measure, migrate, mitigate, mobilize, model, monitor, motivate

**N–R:** navigate, optimize, orchestrate, organize, outperform, penetrate, prioritize, produce, propel, quantify, recommend, rectify, reduce, reinforce, resolve, retain, streamline, strengthen

**S–Z:** scrutinize, secure, segment, standardize, stimulate, stratify, transform, uncover, validate, verify, visualize

---

## Rule 4 — Verb Form Discipline

Always select the correct grammatical form of the verb:

- **Active voice, present tense** for current-state descriptions: *"The system monitors 27,000 devices."*
- **Past tense** for completed actions: *"The team deployed the update in Q3."*
- **Gerund (-ing)** for ongoing processes or as noun subjects: *"Monitoring device health reduces churn."*
- **Infinitive** for recommendations and next steps: *"To reduce latency, migrate to the edge node."*

Never use passive voice when active is available. Passive obscures the actor and weakens the sentence.

---

## Rule 5 — Editing Checklist

Before finalizing any communication, scan line-by-line for:

1. **Imprecise phrase?** → Apply Rule 1 substitution table
2. **Weak verb (help/make/say/show/support)?** → Apply Rule 2 strong alternatives
3. **Passive voice?** → Rewrite with active subject + strong verb
4. **Nominalizations hiding verbs?** (e.g., "make a determination" → "determine")  → Convert to verb
5. **Gerund available?** → Prefer over noun phrase when subject of sentence

---

## Example Transformations

**Before:** *"The team will carry out an inspection of the devices and make a determination about which ones have shown improvement."*

**After:** *"The team will inspect the devices and determine which ones have improved."*

---

**Before:** *"This solution helps property managers keep track of access events and provides assistance when issues arise."*

**After:** *"This solution enables property managers to track access events and facilitates rapid resolution when issues arise."*

---

**Before:** *"We want to say that the new firmware has given rise to a reduction in connectivity failures."*

**After:** *"The new firmware has reduced connectivity failures by 34%."*
