# Installing the Precise Verbs Skill in Claude

## Quick Start

1. **Download the skill package**
   - Download `precise-verbs-skill.zip`

2. **Extract the files**
   - Unzip `precise-verbs-skill.zip`
   - You should see a folder named `precise-verbs-skill` containing:
     - `SKILL.md` (main skill — the only file Claude reads)
     - `README.md` (overview)
     - `INSTALLATION-GUIDE.md` (this file)

3. **Upload to Claude**
   - In Claude's skill settings, upload the extracted `precise-verbs-skill` folder
   - The complete path should resolve to: `/mnt/skills/user/precise-verbs-skill/SKILL.md`

4. **Verify Installation**
   - Ask Claude: `"Can you read /mnt/skills/user/precise-verbs-skill/SKILL.md?"`
   - Claude should confirm it can access and read the skill

---

## How to Use

Reference the skill explicitly in your prompt — Claude will then apply all verb rules automatically.

### Example Prompts

**Edit an existing draft:**
```
Read the Precise Verbs Skill and edit this email to strengthen the verbs:
[paste your draft]
```

**Write from scratch:**
```
Using the Precise Verbs Skill, write an executive summary of the Q3 churn analysis.
```

**Quick verb audit:**
```
Apply the Precise Verbs Skill and flag every weak or imprecise verb in this document.
```

**Combined with Minto style:**
```
Read the Precise Verbs Skill and write a Minto-style memo recommending 
we expand the device health monitoring program to all 37,000 devices.
```

---

## What Claude Enforces Automatically

When the skill is active, Claude will:

- ✅ Replace imprecise verb phrases ("carry out an inspection of" → "inspect")
- ✅ Eliminate weak verbs (help/make/say/show/support) with precise alternatives
- ✅ Select verbs from the descriptive library for new drafts
- ✅ Rewrite passive voice as active
- ✅ Convert nominalizations back to verbs ("make a determination" → "determine")
- ✅ Apply correct verb form (active, gerund, past tense, infinitive)
- ✅ Run the 5-point editing checklist before finalizing

---

## Troubleshooting

**Claude can't find the skill:**
- Verify the folder is at `/mnt/skills/user/precise-verbs-skill/`
- Confirm `SKILL.md` is inside the folder (not nested in a subfolder)

**Claude isn't applying the rules:**
- Explicitly reference the skill: *"Read the Precise Verbs Skill and then…"*
- For editing tasks, paste the text to edit directly in the same message

**Need to update the rules:**
- Edit `/mnt/skills/user/precise-verbs-skill/SKILL.md` directly
- Changes take effect immediately on the next conversation

---

## Quick Reference

**Trigger phrase:** `"Read the Precise Verbs Skill and [your request]"`

**Key substitutions:**
- "carry out an inspection of" → **inspect**
- "make a suggestion" → **suggest**
- "provide assistance" → **help** → **facilitate** (further upgrade)
- "show improvement" → **improve**
- "give rise to" → **cause**

**Weak → Strong:**
- help → facilitate, stimulate, encourage
- make → produce, generate, construct
- show → demonstrate, reveal, present
- support → reinforce, bolster, strengthen
