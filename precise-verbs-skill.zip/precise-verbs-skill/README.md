# Precise Verbs Skill

A Claude skill that enforces the use of descriptive, precise, and strong verbs across all business communications — executive summaries, emails, reports, and consulting deliverables.

Sourced from CellGate's internal *Descriptive and Precise Verbs* reference guide.

## What It Does

- Replaces imprecise multi-word verb phrases with single precise verbs (22-entry lookup table)
- Eliminates weak verbs (help, make, say, show, support) with strong, specific alternatives
- Provides a curated A–Z library of 80+ descriptive action verbs for drafting
- Enforces active voice, correct verb form, and elimination of nominalizations
- Includes a pre-send editing checklist with before/after transformation examples

## Skill Location

Once installed: `/mnt/skills/user/precise-verbs-skill/SKILL.md`

## Version

**v1.0 — February 2026**
