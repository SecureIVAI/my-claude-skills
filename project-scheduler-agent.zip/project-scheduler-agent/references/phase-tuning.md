# Phase Duration Tuning Guide

Default phase allocations work well for most CellGate projects, but certain project types
warrant different distributions. This reference explains how to adjust.

## Default Allocation (used when Project Type is unset or unknown)

| Phase              | % of Total Duration |
|--------------------|---------------------|
| Discovery          | 10%                 |
| Design / Planning  | 15%                 |
| Implementation     | 45%                 |
| Testing / QA       | 20%                 |
| Launch             | 10%                 |

## Project Type Overrides

If the task's **Project Type** custom field matches one of these values, use the adjusted
percentages instead:

### Infrastructure / Platform

Heavy implementation with extended testing. Typical for Fabric, Azure, or network projects.

| Phase              | % |
|--------------------|---|
| Discovery          | 10% |
| Design / Planning  | 20% |
| Implementation     | 35% |
| Testing / QA       | 25% |
| Launch             | 10% |

### Integration / Data Pipeline

Front-loaded discovery and design to define schemas and API contracts.

| Phase              | % |
|--------------------|---|
| Discovery          | 15% |
| Design / Planning  | 20% |
| Implementation     | 35% |
| Testing / QA       | 20% |
| Launch             | 10% |

### Quick Fix / Hotfix

Minimal discovery, compressed timeline, emphasis on testing and fast launch.

| Phase              | % |
|--------------------|---|
| Discovery          | 5%  |
| Design / Planning  | 10% |
| Implementation     | 40% |
| Testing / QA       | 30% |
| Launch             | 15% |

### Customer-Facing Feature

Balanced allocation with extra time for UAT and launch readiness.

| Phase              | % |
|--------------------|---|
| Discovery          | 10% |
| Design / Planning  | 15% |
| Implementation     | 40% |
| Testing / QA       | 25% |
| Launch             | 10% |

## Rounding Rules

- Always round phase durations to whole days.
- If rounding causes the total to exceed the available days, subtract 1 day from the
  longest phase (Implementation).
- If rounding causes the total to fall short, add remaining days to Implementation.
- The Launch phase end date must always equal the project Due Date exactly.

## Minimum Duration Rules

- No phase may be shorter than 1 day.
- If total project duration is fewer than 5 days, collapse to 3 phases:
  Discovery + Design/Planning (combined), Implementation, Testing/QA + Launch (combined).
- If total duration is 1–2 days, do not create subtask phases. Flag the task as
  "too short for phased scheduling" in the briefing email.

## Manual Override Respect

If a phase subtask already has dates set by a human, the agent must not overwrite them.
The agent only fills in dates for phases that have no dates or phases it is creating new.
