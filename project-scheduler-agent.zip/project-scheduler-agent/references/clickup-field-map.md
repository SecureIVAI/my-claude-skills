# ClickUp Field Mapping — Planned Projects by Qtr.

This reference maps the custom field names used in the **Planned Projects by Qtr.** ClickUp
list to the logic in the Project Scheduler Super Agent.

## Discovery: Finding Field IDs

On first run, the agent must discover custom field IDs dynamically because they vary per
workspace. Use the ClickUp MCP tool to retrieve the list's custom fields, then match by name.

```
1. Get the list details (including custom_fields) for the target list.
2. For each custom field, match field.name against the canonical names below.
3. Store the field.id for use in task updates.
```

## Canonical Custom Fields

| Canonical Name       | Expected ClickUp Field Name | Type     | Used For                          |
|----------------------|-----------------------------|----------|-----------------------------------|
| Goal Start Date      | `Goal Start Date`           | date     | Source of truth for Start Date    |
| Delivery Date        | `Delivery Date`             | date     | Source of truth for Due Date      |
| Project Type         | `Project Type`              | dropdown | Determines phase % allocation     |
| Priority             | `Priority`                  | dropdown | Escalation urgency in comments    |
| Project Owner        | `Project Owner`             | people   | Who receives direct follow-ups    |

## Built-in ClickUp Fields Used

| Field          | Purpose                                      |
|----------------|----------------------------------------------|
| `start_date`   | Task start date (set from Goal Start Date)   |
| `due_date`     | Task due date (set from Delivery Date)       |
| `status`       | Current workflow status                      |
| `assignees`    | People assigned to the task                  |
| `subtasks`     | Child tasks representing project phases      |

## Field Name Fuzzy Matching

If exact name matches fail, attempt case-insensitive matching and partial matching:

- "goal start" → Goal Start Date
- "delivery" → Delivery Date
- "project type" or "type" → Project Type

If no match is found after fuzzy attempts, list all available custom fields for the user
and ask them to confirm the correct mapping. Store confirmed mappings for future runs.

## Notes

- Custom field IDs are workspace-specific. Never hard-code them.
- Date fields in ClickUp use Unix timestamps in milliseconds.
- When setting dates via the API, convert from human-readable dates to ms timestamps.
