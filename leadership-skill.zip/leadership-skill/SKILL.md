---
name: leadership-coaching
description: >
  Applies CellGate's leadership framework to evaluate, coach, and improve leadership execution across the organization. Use this skill whenever reviewing meeting notes, agendas, or recaps; drafting delegation plans or accountability structures; evaluating decisions or proposals; preparing 1:1 coaching notes or team development content; analyzing organizational structure or role clarity; reviewing communications for strategic vs. tactical clarity; or when the user mentions leadership gaps, meeting effectiveness, decision quality, accountability, standards, or team alignment. Also trigger when asked to critique, improve, or coach on any management activity. Apply even when the user doesn't explicitly say "leadership" — if the output involves managing people, making decisions, running meetings, or setting direction, these principles apply.
---

# CellGate Leadership Coaching Framework

## Purpose

This skill encodes CellGate's leadership philosophy into a practical evaluation and coaching tool. It addresses two core organizational opportunities:

1. **Leaders can expand on their leadership execution** — closing gaps in meeting effectiveness, decision rigor, accountability clarity, and strategic focus.
2. **Teams must better connect to understand, support, and engage in the value to CellGate** — ensuring cross-functional alignment and shared purpose.

## The 10 Leadership Definitions

These definitions form the evaluation criteria for all coaching, review, and feedback activities. Claude should internalize these as the standard against which leadership activity is measured.

### L1 — Intensity in Observation
Leadership means intensity in observation — which triggers detection of issues, misalignments, and opportunities. Being deeply observant means higher information extraction.

**Apply when:** Reviewing meeting notes, status updates, or reports. Ask: Did the leader detect what matters? What was missed?

### L2 — The Three Listening Questions
Leadership is about three key questions:
- (a) What's being said that's not being heard?
- (b) What is not being said?
- (c) What's being said that I'm not hearing?

**Apply when:** Evaluating communications, meeting dynamics, or team feedback. Surface the unspoken.

### L3 — Brilliance in Decision Making
Leadership means brilliance in decision-making process:
- Identify the drivers
- Define the metrics
- Analytically determine the facts — cull the rest
- Identify the bias
- Assess what's missing (long-tail probability, what-if scope, exceptions)
- Define expected outcomes
- Apply better framing

**Apply when:** Reviewing proposals, business cases, strategic plans, or any decision point. Ensure analytical rigor.

### L4 — The Execution Cycle
Leadership is about listening, assessing, proving, improving, executing, and setting standards.

**Apply when:** Evaluating whether a leader or team is progressing through this cycle or stuck at one stage.

### L5 — The Four Ds
Leadership is about doing it, delegating it, deferring it, or dropping it.

**Apply when:** Reviewing task lists, backlogs, meeting action items, or workload discussions. Every item should map to one of these four dispositions.

### L6 — Pivot Readiness
Leadership is about knowing when and how to pivot and let go of the status quo.

**Apply when:** Evaluating resistance to change, sunk-cost reasoning, or stalled initiatives.

### L7 — Servant Leadership with Results
Leadership is about serving others, setting goals, taking calculated risk, selecting an "A" team, executing for results, knowing what's important — and knowing what to ignore.

**Apply when:** Assessing team composition decisions, goal-setting quality, prioritization, and whether leaders are serving their teams or extracting from them.

### L8 — Working Backwards
Leadership means proving you are heading in the right direction by working backwards from the desired target outcome(s).

**Apply when:** Reviewing plans, roadmaps, or strategies. Check: Is the target outcome clearly defined? Does every step trace back to it?

### L9 — Structure and Accountability
Leadership is about defining organizational structure and accountability.

**Apply when:** Evaluating org design, role clarity, ownership of deliverables, or when accountability is obscure.

### L10 — Value Creation
Leadership is about value creation and delivering this value to a market.

**Apply when:** Assessing whether activities, projects, or initiatives connect to market value delivery. Flag activity that doesn't create or protect value.

---

## How Claude Applies This Framework

### Meeting Review Mode
When reviewing meeting notes, agendas, or recaps:
1. Score against relevant definitions (not all 10 will apply to every meeting)
2. Identify specific gaps with concrete examples from the content
3. Distinguish strategic vs. tactical content — flag when meetings conflate the two
4. Check for: clear accountability assignments, defined next steps with owners, decision quality, time efficiency
5. Provide 2-3 actionable recommendations tied to specific definitions

**Output format:**
```
MEETING REVIEW: [Title/Date]

STRENGTHS (with definition references):
- [Specific observation] → aligns with [L#]

GAPS (with definition references):
- [Specific observation] → gap in [L#]
- Common gaps to check: wasted time/effort, missed opportunities, undetected mistakes, inadequate direction, obscure accountability, domain incompetence, inefficient execution, strategic/tactical confusion, inadequate standards

RECOMMENDATIONS:
1. [Actionable improvement tied to L#]
2. [Actionable improvement tied to L#]
```

### Decision Review Mode
When evaluating a decision or proposal:
1. Apply L3's full decision-making checklist systematically
2. Apply L8's working-backwards test
3. Check for L6 pivot readiness — is status quo bias present?
4. Assess whether L10 value creation is clearly connected
5. Identify missing elements explicitly

### Coaching & Development Mode
When generating coaching content, 1:1 guides, or development materials:
1. Select the 2-3 most relevant definitions for the individual's growth area
2. Frame gaps constructively — these are expansion opportunities, not failures
3. Provide specific behavioral indicators for what "good" looks like
4. Connect individual growth to value to CellGate engagement (Opportunity #2)
5. Include self-assessment questions derived from L2's three listening questions

### Communication Review Mode
When reviewing emails, Slack messages, or documents from leaders:
1. Check for L9 clarity — is accountability explicitly defined?
2. Apply L2 — what's not being said? What might not be heard?
3. Assess L4 — does the communication drive the execution cycle forward?
4. Verify strategic vs. tactical framing is appropriate for the audience

### Delegation & Prioritization Mode
When helping with task management or workload:
1. Apply L5's Four Ds to every item
2. For "do it" items, apply L8 working-backwards validation
3. For "delegate it" items, verify L9 accountability is clear
4. For "defer it" items, set a review trigger
5. For "drop it" items, apply L7 — confirm it's something to ignore

---

## Tone and Approach

- Frame all feedback as **expansion opportunities**, not criticism
- Be specific — cite exact content and tie to exact definitions
- Distinguish between strategic gaps (L6, L8, L10) and tactical gaps (L4, L5, L9)
- When multiple gaps exist, prioritize the 2-3 with highest impact
- Always connect back to the two core opportunities: leadership execution expansion and value to CellGate connectivity
- Use direct, concise language — no filler, no hedging on observable gaps
